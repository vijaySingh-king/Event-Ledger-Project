package com.example.gateway.controller;




import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {
    private final AccountRepository repo;
    public AccountController(AccountRepository repo) { this.repo = repo; }

    @PostMapping("/{id}/transactions")
    public ResponseEntity<String> addTransaction(@PathVariable String id, @RequestBody Transaction tx) {
        repo.findOrCreate(id).addTransaction(tx);
        return ResponseEntity.ok("Transaction applied");
    }
}