package com.example.gateway.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.gateway.Model.Event;
import com.example.gateway.exception.AccountServiceUnavailableException;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import java.util.Map;

@Component
public class AccountClient {

    private static final Logger log = LoggerFactory.getLogger(AccountClient.class);

    private final RestTemplate restTemplate;
    private final String accountServiceUrl;

    public AccountClient(RestTemplate restTemplate,
                         @Value("${account.service.url}") String accountServiceUrl) {
        this.restTemplate = restTemplate;
        this.accountServiceUrl = accountServiceUrl;
    }

    /**
     * Calls Account Service to apply a transaction.
     * Wrapped with Resilience4j Circuit Breaker.
     * After 5 failures (50% rate), circuit opens for 10 seconds.
     */
    @CircuitBreaker(name = "accountService", fallbackMethod = "applyTransactionFallback")
    public ResponseEntity<String> applyTransaction(Event event, String traceId) {
        String url = accountServiceUrl + "/accounts/" + event.getAccountId() + "/transactions";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-Trace-Id", traceId); // Trace propagation

        Map<String, Object> body = Map.of(
                "eventId",         event.getEventId(),
                "type",            event.getType().name(),
                "amount",          event.getAmount(),
                "currency",        event.getCurrency(),
                "eventTimestamp",  event.getEventTimestamp().toString()
        );

        log.info("Forwarding event={} to Account Service traceId={}", event.getEventId(), traceId);
        return restTemplate.exchange(url, HttpMethod.POST,
                new HttpEntity<>(body, headers), String.class);
    }

    /**
     * Fallback: called when circuit is open OR the call throws.
     * Must have same parameters + Throwable at the end.
     */
    public ResponseEntity<String> applyTransactionFallback(Event event, String traceId, Exception ex) {
        log.warn("Circuit breaker fallback triggered event={} traceId={} reason={}",
                event.getEventId(), traceId, ex.getMessage());
        throw new AccountServiceUnavailableException(
                "Account Service is currently unavailable. Please try again later.", ex);
    }
}
