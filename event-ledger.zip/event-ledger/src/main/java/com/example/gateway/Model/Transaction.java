package com.example.gateway.Model;

public class Transaction {

}
