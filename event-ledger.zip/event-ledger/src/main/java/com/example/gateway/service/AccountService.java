package com.example.gateway.service;


import org.springframework.stereotype.Service;

@Service
public class AccountService {

    private final AccountRepository accountRepository;

    public AccountService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public void processTransaction(String accountId, Transaction transaction) {
        Account account = accountRepository.findOrCreate(accountId);
        
        // Apply business logic: Update balance based on transaction type
        if ("CREDIT".equalsIgnoreCase(transaction.type())) {
            account.setBalance(account.getBalance() + transaction.amount());
        } else if ("DEBIT".equalsIgnoreCase(transaction.type())) {
            if (account.getBalance() < transaction.amount()) {
                throw new RuntimeException("Insufficient funds for account: " + accountId);
            }
            account.setBalance(account.getBalance() - transaction.amount());
        }

        account.addTransaction(transaction);
        // Repository is effectively updated by reference if using ConcurrentHashMap in repo
    }
}