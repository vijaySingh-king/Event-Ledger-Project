package com.example.gateway.Model;


import java.util.ArrayList;
import java.util.List;

public class Account {
    private String id;
    private double balance;
    private List<Transaction> transactions = new ArrayList<>();

    public Account(String id) { this.id = id; }
    public void addTransaction(Transaction t) {
        this.transactions.add(t);
        if ("CREDIT".equals(t.type())) balance += t.amount();
        else balance -= t.amount();
    }
    // Getters
    public String getId() { return id; }
    public double getBalance() { return balance; }
 // Add to Account.java
    public void setBalance(double balance) { 
        this.balance = balance; 
    }
		
	}
}