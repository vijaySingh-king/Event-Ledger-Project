package com.exmaple.gateway.repo;


import org.springframework.stereotype.Repository;

import com.example.gateway.Model.Account;

import java.util.concurrent.ConcurrentHashMap;

@Repository
public class AccountRepository {
    private final ConcurrentHashMap<String, Account> store = new ConcurrentHashMap<>();

    public Account findOrCreate(String accountId) {
        return store.computeIfAbsent(accountId, Account::new);
    }
}