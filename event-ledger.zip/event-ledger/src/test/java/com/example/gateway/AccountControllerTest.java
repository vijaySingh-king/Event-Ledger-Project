package com.example.gateway;

import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.gateway.Model.Transaction;
import com.example.gateway.controller.AccountController;
import com.example.gateway.service.AccountService;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;

@WebMvcTest(AccountController.class)
public class AccountControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private AccountService accountService;

    @Test
    public void testAddTransaction_Success() throws Exception {
        String json = """
            {
                "eventId": "tx_123",
                "type": "CREDIT",
                "amount": 100.0,
                "currency": "USD",
                "eventTimestamp": "2026-07-09T10:00:00Z"
            }
            """;

        doNothing().when(accountService).processTransaction(eq("acc_1"), any(Transaction.class));

        mockMvc.perform(post("/accounts/acc_1/transactions")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk());
    }
}